from functools import partial
from transmatrix_ngmc.lib.core.transform import ROLLING_MAX, ROLLING_MIN
from transmatrix_py.generator.py_ops import PyOperators
from transmatrix_ngmc.lib.funcs.talib.momentum_indicators import (CCI_FFILL as CCI, MOM_FFILL as MOM, ADX_FFILL as ADX, APO_FFILL as APO, RSI_FFILL as RSI, STOCH_FFILL as STOCH)
from transmatrix_py.story import *
from transmatrix_ngmc.ref import EventSelect
from transmatrix_ngmc.lib.core.market import MarketDataAPI_impl, Market
from transmatrix_py.client import GetItem, TimeTable

# 定义基础数据字段
CODE = 'I9999.DCE'
SPAN = ['2024-01-04 09:00:00', '2024-01-31 15:00:00']

data = TimeTable('meta_data', 'future_bar_1min', 'datetime',  '2024-01-04 09:00:00', '2024-01-31 15:00:00', 'code', ['I9999.DCE'])
def close():
    close = GetItem(data, 'close')
    return close

def open():
    open = GetItem(data, 'open')
    return open

def high():
    high = GetItem(data, 'high')
    return high

def low():
    low = GetItem(data, 'low')
    return low

baseline_constants = [(open, 'open'), (high, 'high'), (low, 'low'), (close, 'close')]
OPEN, HIGH, LOW, CLOSE = GetItem(data, 'open'), GetItem(data, 'high'), GetItem(data, 'low'), GetItem(data, 'close')

# 定义基础算子表达式
baseline_nodes = [
    (PyOperators.Add, 2, 'add'),
    (PyOperators.Minus, 2, 'minus'),
    (PyOperators.Multiply, 2, 'multiply'),
    (partial(ROLLING_MIN, 10), 1, 'ROLLING_MIN'),
    (partial(ROLLING_MAX, 10), 1, 'ROLLING_MAX'),
    (partial(CCI, 12), 3,  'CCI_12'),
    (partial(CCI, 26), 3,  'CCI_26'),
    (partial(CCI, 144), 3,  'CCI_144'),
    (partial(MOM, 12), 1,  'MOM_12'),
    (partial(MOM, 26), 1,  'MOM_26'),
    (partial(MOM, 144), 1,  'MOM_144'),
    (partial(ADX, 12), 3,  'ADX_12'),
    (partial(ADX, 26), 3,  'ADX_26'),
    (partial(ADX, 144), 3,  'ADX_144'),
    (partial(APO, 12, 26), 1,  'APO_12_26'),
    (partial(APO, 26, 144), 1,  'APO_26_144'),
    (partial(RSI, 12), 1,  'RSI_12'),
    (partial(RSI, 26), 1,  'RSI_26'),
    (partial(RSI, 144), 1,  'RSI_144'),
    (partial(STOCH, 12, 5, 5), 3,  'STOCH_12'),
    (partial(STOCH, 26, 12, 12), 3,  'STOCH_26'),
    (partial(STOCH, 144, 64, 64), 3,  'STOCH_144'),
]
