import numpy as np
from transmatrix_ngmc.ref import EventSelect

from transmatrix_ngmc.lib.funcs.talib.momentum_indicators import (
    CCI,
    MOM,
)

from transmatrix_ngmc.lib.core.transform import ROLLING, MAX, PyExpression, MIN, EXP, SHIFT
from transmatrix_py.story import *
from transmatrix_py.story.core.structures import ORDER_OFFSET

@generator()
class Trendy(PyGenerator):
    
    signal: PyExpression
    md: BaseFuturesMd
    td: BaseTd

    fast_window = 5
    slow_window = 100

    def init_generator(self):
        self.reset_stats()

    def reset_stats(self):
        self.fast_beta = 1 / self.fast_window
        self.fast_alpha = 1 - self.fast_beta
        self.slow_beta = 1 / self.slow_window
        self.slow_alpha = 1 - self.slow_beta
        self.fast_signal = np.nan
        self.slow_signal = np.nan 
        self._fast_signal = np.nan
        self._slow_signal = np.nan

        
    @g_callback('signal')
    def on_signal(self, data):
        
        if data is None or np.isnan(data): return 
        if np.isnan(self.fast_signal):
            self._fast_signal = data
            self._slow_signal = data
            self.fast_signal = data
            self.slow_signal = data 
            return 
        
        self._fast_signal = self.fast_signal
        self._slow_signal = self.slow_signal
        self.fast_signal = self.fast_signal * self.fast_alpha + data * self.fast_beta
        self.slow_signal = self.slow_signal * self.slow_alpha + data * self.slow_beta
        

    @g_callback('md', BaseFuturesMd.event.BAR_UPDATE)
    def on_bar(self, bar):
        
        if self._fast_signal < self._slow_signal and self.fast_signal > self.slow_signal:
            pos = self.td.get_netpos(self.md.code)
            offset = ORDER_OFFSET.OPEN if pos >= 0 else ORDER_OFFSET.CLOSE
            self.td.buy(bar.close, 1, offset, self.md.code)

        if self._fast_signal > self._slow_signal and self.fast_signal < self.slow_signal:
            pos = self.td.get_netpos(self.md.code)
            offset = ORDER_OFFSET.OPEN if pos <= 0 else ORDER_OFFSET.CLOSE
            self.td.sell(bar.close, 1, offset, self.md.code)

    def _do_report(self, rr: GeneratorReport):
        stats = self.td.get_daily_stats()
        trades = self.td.get_trade_table()
        rr.report['stats'] = stats
        rr.report['trades'] = trades

