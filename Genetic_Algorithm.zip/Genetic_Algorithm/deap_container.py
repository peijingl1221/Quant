# import sys; sys.path.append('demo/530/DEAP')
from typing import List
from datetime import datetime
import random; random.seed(318)
from multiprocessing import Pool

from deap import algorithms
from deap import base
from deap import creator
from deap import tools
from deap import gp

from transmatrix_py.generator.py_expression import traverse

class DeapContainer:

    def __init__(
        self,
        baseline_nodes: List,
        baseline_constants: List,
        population = 30,
        num_gen = 5,
        cxpb = 0.5,
        mutpb = 0.1,
        hof = 300,
        node_length_range: List = [2, 4],
        mode_mut: List = [0, 2],
    ) -> None:
        
        self.job(
            baseline_nodes, baseline_constants, 
            population, hof, node_length_range, mode_mut,
            num_gen = num_gen, cxpb = cxpb, mutpb = mutpb
        )
        

    def job(
        self,
        baseline_nodes: List,
        baseline_constants: List,
        population = 30,
        hof = 300,
        node_length_range: List = [2, 4],
        mode_mut: List = [0, 2],
        num_gen = 5,
        cxpb = 0.5,
        mutpb = 0.1,
    ):
        pset = gp.PrimitiveSet("MAIN", 0)
        [pset.addPrimitive(node, arity, name = name) for node, arity, name in baseline_nodes]
        [pset.addEphemeralConstant(name, constant) for constant, name in baseline_constants]
        creator.create("FitnessMin", base.Fitness, weights=(-1,))
        creator.create("Individual", gp.PrimitiveTree, fitness=creator.FitnessMin)
        toolbox = base.Toolbox()
        toolbox.register("expr", gp.genHalfAndHalf, pset=pset, min_= node_length_range[0], max_= node_length_range[1])
        toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.expr)
        toolbox.register("population", tools.initRepeat, list, toolbox.individual)
        toolbox.register("compile", traverse, pset=pset)
        # toolbox.register('map', mp_map)
        toolbox.register("select", tools.selTournament, tournsize=3)
        toolbox.register("mate", gp.cxOnePoint)
        toolbox.register("expr_mut", gp.genFull, min_= mode_mut[0], max_ = mode_mut[1])
        toolbox.register("mutate", gp.mutUniform, expr=toolbox.expr_mut, pset=pset)
        self.pop = toolbox.population(n = population)
        self.hof = tools.HallOfFame(hof)
        self.toolbox = toolbox
        self.num_gen = num_gen
        self.cxpb = cxpb
        self.mutpb = mutpb

    def eaSimple(self, task: callable):
        self.toolbox.register("evaluate", task)
        algorithms.eaSimple(self.pop, self.toolbox, self.cxpb, self.mutpb, self.num_gen, halloffame = self.hof)
        self.best_ind = self.hof[-1]
        self.best_fitness = self.best_ind.fitness.values[0]
        print("Best individual is:", self.best_ind)
        print("Best fitness is:", self.best_fitness)
        self.result_generator = self.toolbox.compile(expr=self.best_ind)
        t = datetime.now().strftime('%Y-%m-%d %H:%M')
        with open(f'factor_{t}.txt', 'w') as f: f.write(str(self.result_generator))
        return self.result_generator
    
    
    

def mp_map(*args): 
    with Pool() as pool: 
        return pool.map(*args)

